"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var softwareOrderController_1 = require("./softwareOrderController");
function default_1(server) {
    var orderSoftware = new softwareOrderController_1.SoftwareOrderController();
    server.route(orderSoftware.addSoftwareOrders());
    server.route(orderSoftware.getSoftwareOrders());
    server.route(orderSoftware.updateSoftwareOrders());
    server.route(orderSoftware.deleteSoftwareOrders());
    server.route(orderSoftware.softwareOrderById());
    server.route(orderSoftware.orderDetailsByEmployee());
}
exports.default = default_1;
