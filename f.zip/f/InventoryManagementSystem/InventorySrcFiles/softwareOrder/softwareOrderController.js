"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SoftwareOrderController = void 0;
var Joi = __importStar(require("joi"));
var SoftwareOrderController = /** @class */ (function () {
    function SoftwareOrderController() {
    }
    SoftwareOrderController.prototype.addSoftwareOrders = function () {
        return {
            method: "POST",
            path: "/addSoftwareOrders/{softwareId}/{employeeId}",
            handler: function (request, h) {
                return __awaiter(this, void 0, void 0, function () {
                    var dataBase, getOrderTableData, getSoftwareTableData, getEmployeeTableData, softwareIds, employeeIds, date, softwareData, employeeData, createOrder, orderData, joinData, err_1;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                _a.trys.push([0, 14, , 15]);
                                dataBase = request.getDb("InventoryManagementDatabase");
                                getOrderTableData = dataBase.models.orderData;
                                getSoftwareTableData = dataBase.models.softwares //software table
                                ;
                                getEmployeeTableData = dataBase.models.employee //employee table
                                ;
                                softwareIds = request.params.softwareId;
                                employeeIds = request.params.employeeId;
                                date = request.payload.date;
                                return [4 /*yield*/, getSoftwareTableData.findOne({
                                        attributes: ['softwareId', 'price', 'quantity'],
                                        where: { softwareId: softwareIds },
                                    })
                                    //check employee present or not
                                ];
                            case 1:
                                softwareData = _a.sent();
                                if (!(softwareData !== null)) return [3 /*break*/, 12];
                                return [4 /*yield*/, getEmployeeTableData.findOne({
                                        attributes: ['employeeId'],
                                        where: { employeeId: employeeIds },
                                    })];
                            case 2:
                                employeeData = _a.sent();
                                if (!(employeeData !== null)) return [3 /*break*/, 10];
                                if (!(request.query.purchase <= softwareData.quantity)) return [3 /*break*/, 8];
                                return [4 /*yield*/, getOrderTableData.create({
                                        softwareId: softwareIds,
                                        employeeId: employeeIds,
                                        quantity: request.query.purchase,
                                        priceDetails: softwareData.price,
                                        date: date,
                                    })];
                            case 3:
                                createOrder = _a.sent();
                                return [4 /*yield*/, getOrderTableData.findOne({
                                        attributes: ['orderId', 'employeeId', 'softwareId', 'quantity', 'priceDetails'],
                                        where: { orderId: createOrder.orderId }
                                    })];
                            case 4:
                                orderData = _a.sent();
                                // update the values to database
                                softwareData.quantity = softwareData.quantity - orderData.quantity;
                                orderData.priceDetails = softwareData.price * orderData.quantity;
                                return [4 /*yield*/, orderData.save()];
                            case 5:
                                _a.sent();
                                return [4 /*yield*/, softwareData.save()
                                    //software and order table join and get all details from order data
                                ];
                            case 6:
                                _a.sent();
                                return [4 /*yield*/, getSoftwareTableData.findOne({
                                        include: [
                                            {
                                                model: getOrderTableData,
                                                required: true,
                                                attributes: ['orderId', 'employeeId', 'quantity', 'priceDetails', 'date'],
                                                where: { orderId: createOrder.orderId }
                                            }
                                        ],
                                        attributes: ['Name', 'description', 'price', 'imagePath']
                                    })];
                            case 7:
                                joinData = _a.sent();
                                return [2 /*return*/, JSON.stringify(joinData, null, 2)];
                            case 8: return [2 /*return*/, ' sorry no quantity available'];
                            case 9: return [3 /*break*/, 11];
                            case 10: return [2 /*return*/, 'wrong employee id not available'];
                            case 11: return [3 /*break*/, 13];
                            case 12: return [2 /*return*/, 'wrong software id not available'];
                            case 13: return [3 /*break*/, 15];
                            case 14:
                                err_1 = _a.sent();
                                console.log(err_1);
                                return [3 /*break*/, 15];
                            case 15: return [2 /*return*/];
                        }
                    });
                });
            },
            options: {
                validate: {
                    params: Joi.object({
                        softwareId: Joi.number(),
                        employeeId: Joi.number().min(1)
                    }),
                    query: Joi.object({
                        purchase: Joi.number().min(1)
                    }),
                    payload: Joi.object({
                        date: Joi.date()
                    }),
                },
                description: "Add softwareOrders",
                notes: "Returns a todo item by the id passed in the path",
                tags: ["api"], // ADD THIS TAG
            },
        };
    };
    SoftwareOrderController.prototype.getSoftwareOrders = function () {
        var _this = this;
        return {
            method: "GET",
            path: "/getSoftwareOrders",
            handler: function (request, h) { return __awaiter(_this, void 0, void 0, function () {
                var dataBase, getSoftwareTableData, getOrderTableData, softwareData, err_2;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            _a.trys.push([0, 3, , 4]);
                            return [4 /*yield*/, request.getDb("InventoryManagementDatabase")];
                        case 1:
                            dataBase = _a.sent();
                            getSoftwareTableData = dataBase.models.softwares;
                            getOrderTableData = dataBase.models.orderData;
                            return [4 /*yield*/, getSoftwareTableData.findAll({
                                    include: [
                                        {
                                            model: getOrderTableData,
                                            required: true,
                                            attributes: ['orderId', 'employeeId', 'quantity', 'priceDetails', 'date'],
                                            order: [
                                                ['orderId', 'ASC']
                                            ]
                                        }
                                    ],
                                    attributes: ['softwareId', 'Name', 'description', 'price', 'imagePath'],
                                })
                                //if order is present 
                            ];
                        case 2:
                            softwareData = _a.sent();
                            //if order is present 
                            if (softwareData.length >= 1) {
                                return [2 /*return*/, JSON.stringify(softwareData, null, 2)];
                            }
                            else {
                                return [2 /*return*/, h.response({ message: "no softwareOrders" })];
                            }
                            return [3 /*break*/, 4];
                        case 3:
                            err_2 = _a.sent();
                            console.log(err_2);
                            return [3 /*break*/, 4];
                        case 4: return [2 /*return*/];
                    }
                });
            }); },
            options: {
                description: "show softwareOrders",
                notes: "Returns a todo item by the id passed in the path",
                tags: ["api"], // ADD THIS TAG
            },
        };
    };
    SoftwareOrderController.prototype.updateSoftwareOrders = function () {
        return {
            method: "PUT",
            path: "/updateSoftwareOrders/{orderId}/{softwareId}",
            handler: function (request, h) {
                return __awaiter(this, void 0, void 0, function () {
                    var dataBase, getOrderTableData, getSoftwareTableData, softwareId, softwareData, orderData, joinData;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                dataBase = request.getDb("InventoryManagementDatabase");
                                getOrderTableData = dataBase.models.orderData;
                                getSoftwareTableData = dataBase.models.softwares;
                                softwareId = request.params.softwareId;
                                return [4 /*yield*/, getSoftwareTableData.findOne({
                                        attributes: ['price', 'softwareId', 'quantity'],
                                        where: { softwareId: softwareId },
                                    })
                                    //check quantity is available or not
                                ];
                            case 1:
                                softwareData = _a.sent();
                                if (!(softwareData.quantity >= request.payload.quantity)) return [3 /*break*/, 8];
                                return [4 /*yield*/, getOrderTableData.findOne({
                                        attributes: ['orderId', 'softwareId', 'employeeId', 'quantity'],
                                        where: { orderId: request.params.orderId, softwareId: request.params.softwareId },
                                    })];
                            case 2:
                                orderData = _a.sent();
                                if (!orderData) return [3 /*break*/, 6];
                                //update the values to software and order table
                                softwareData.quantity = softwareData.quantity - request.payload.quantity;
                                orderData.quantity = request.payload.quantity;
                                orderData.priceDetails = softwareData.price * request.payload.quantity;
                                return [4 /*yield*/, orderData.save()];
                            case 3:
                                _a.sent();
                                return [4 /*yield*/, softwareData.save()];
                            case 4:
                                _a.sent();
                                return [4 /*yield*/, getSoftwareTableData.findOne({
                                        include: [
                                            {
                                                model: getOrderTableData,
                                                required: true,
                                                attributes: ['orderId', 'employeeId', 'quantity', 'priceDetails', 'date'],
                                                where: { orderId: request.params.orderId }
                                            }
                                        ],
                                        attributes: ['Name', 'description', 'price', 'imagePath']
                                    })];
                            case 5:
                                joinData = _a.sent();
                                return [2 /*return*/, JSON.stringify(joinData, null, 2)];
                            case 6: return [2 /*return*/, 'order id and software id not match'];
                            case 7: return [3 /*break*/, 9];
                            case 8: return [2 /*return*/, 'no quantity available'];
                            case 9: return [2 /*return*/];
                        }
                    });
                });
            },
            options: {
                validate: {
                    params: Joi.object({
                        orderId: Joi.number(),
                        softwareId: Joi.number(),
                    }),
                    payload: Joi.object({
                        quantity: Joi.number().min(1),
                    }),
                },
                description: "update softwareOrders",
                notes: "Returns a todo item by the id passed in the path",
                tags: ["api"], // ADD THIS TAG
            },
        };
    };
    SoftwareOrderController.prototype.deleteSoftwareOrders = function () {
        var _this = this;
        return {
            method: "DELETE",
            path: "/deleteSoftwareOrders/{orderId}",
            handler: function (request, h) { return __awaiter(_this, void 0, void 0, function () {
                var dataBase, getOrderTableData, result, err_3;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            _a.trys.push([0, 3, , 4]);
                            return [4 /*yield*/, request.getDb("InventoryManagementDatabase")];
                        case 1:
                            dataBase = _a.sent();
                            getOrderTableData = dataBase.models.orderData;
                            return [4 /*yield*/, getOrderTableData.destroy({
                                    where: { orderId: request.params.orderId }
                                })];
                        case 2:
                            result = _a.sent();
                            if (result) {
                                console.log(result);
                                return [2 /*return*/, JSON.stringify(result, null, 2)];
                            }
                            else {
                                return [2 /*return*/, h.response({ message: "no softwareOrders" })];
                            }
                            return [3 /*break*/, 4];
                        case 3:
                            err_3 = _a.sent();
                            console.log(err_3);
                            return [3 /*break*/, 4];
                        case 4: return [2 /*return*/];
                    }
                });
            }); },
            options: {
                validate: {
                    params: Joi.object({
                        orderId: Joi.number(),
                    }),
                },
                description: "delete softwareOrders",
                notes: "Returns a todo item by the id passed in the path",
                tags: ["api"], // ADD THIS TAG
            },
        };
    };
    SoftwareOrderController.prototype.softwareOrderById = function () {
        var _this = this;
        return {
            method: "GET",
            path: "/softwareOrderById/{orderId}",
            handler: function (request, h) { return __awaiter(_this, void 0, void 0, function () {
                var dataBase, getSoftwareTableData, getOrderTableData, orderIds, result, err_4;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            _a.trys.push([0, 3, , 4]);
                            return [4 /*yield*/, request.getDb("InventoryManagementDatabase")];
                        case 1:
                            dataBase = _a.sent();
                            getSoftwareTableData = dataBase.models.softwares;
                            getOrderTableData = dataBase.models.orderData;
                            orderIds = request.params.orderId;
                            return [4 /*yield*/, getSoftwareTableData.findOne({
                                    include: [
                                        {
                                            model: getOrderTableData,
                                            required: true,
                                            attributes: ['orderId', 'employeeId', 'quantity', 'priceDetails', 'date'],
                                            where: { orderId: orderIds }
                                        }
                                    ],
                                    attributes: ['Name', 'description', 'price', 'imagePath']
                                })];
                        case 2:
                            result = _a.sent();
                            if (result) {
                                return [2 /*return*/, JSON.stringify(result, null, 2)];
                            }
                            else {
                                return [2 /*return*/, h.response({ message: "no softwareOrders" })];
                            }
                            return [3 /*break*/, 4];
                        case 3:
                            err_4 = _a.sent();
                            console.log(err_4);
                            return [3 /*break*/, 4];
                        case 4: return [2 /*return*/];
                    }
                });
            }); },
            options: {
                validate: {
                    params: Joi.object({
                        orderId: Joi.number(),
                    }),
                },
                description: "show softwareOrders by id",
                notes: "Returns a todo item by the id passed in the path",
                tags: ["api"], // ADD THIS TAG
            }
        };
    };
    SoftwareOrderController.prototype.orderDetailsByEmployee = function () {
        var _this = this;
        return {
            method: "GET",
            path: "/orderDetailsByEmployee/{employeeId}",
            handler: function (request, h) { return __awaiter(_this, void 0, void 0, function () {
                var dataBase, getEmployeeTableData, getOrderTableData, employeeIds, joinData, err_5;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            _a.trys.push([0, 3, , 4]);
                            return [4 /*yield*/, request.getDb("InventoryManagementDatabase")];
                        case 1:
                            dataBase = _a.sent();
                            getEmployeeTableData = dataBase.models.employee;
                            getOrderTableData = dataBase.models.orderData;
                            employeeIds = request.params.employeeId;
                            return [4 /*yield*/, getEmployeeTableData.findOne({
                                    include: [
                                        {
                                            model: getOrderTableData,
                                            required: true,
                                        },
                                    ],
                                    attributes: ['firstName', 'lastName'],
                                    where: { employeeId: employeeIds }
                                })];
                        case 2:
                            joinData = _a.sent();
                            if (joinData) {
                                return [2 /*return*/, JSON.stringify(joinData, null, 2)];
                            }
                            else {
                                return [2 /*return*/, h.response({ message: "no employee" })];
                            }
                            return [3 /*break*/, 4];
                        case 3:
                            err_5 = _a.sent();
                            console.log(err_5);
                            return [3 /*break*/, 4];
                        case 4: return [2 /*return*/];
                    }
                });
            }); },
            options: {
                validate: {
                    params: Joi.object({
                        employeeId: Joi.number(),
                    }),
                },
                description: "show employee by id",
                notes: "Returns a todo item by the id passed in the path",
                tags: ["api"], // ADD THIS TAG
            }
        };
    };
    return SoftwareOrderController;
}());
exports.SoftwareOrderController = SoftwareOrderController;
// const result=await sequelize.query(`select employees."firstName",employees."lastName","orderData".* ,"softwares".* from "employees" inner join "orderData" on "employees"."employeeId"="orderData"."employeeId" inner join "softwares"  on "softwares"."softwareId"="orderData"."softwareId" where "employees"."employeeId"=${employeeIds}`,{
//   type:Sequelize.QueryTypes.SELECT
// })
//         public addSoftwareOrders(){
//             return{
//               method: "POST",
//               path: "/addSoftwareOrders/{softwareId}",
//               handler: async function (request: any, h: Hapi.ResponseToolkit) {
//                try{
//                 const dataBase = request.getDb("InventoryManagementDatabase");
//                 // console.log(dataBase)
//                 const getOrderTableData = dataBase.models.softwareOrders;
//                 const getTableData1=dataBase.models.softwares
//                // console.log("data", getTableData1.softwareId)
//                 const softwareIds=request.params.softwareId
//                 console.log("database", getTableData1);
//                 const {quantity,priceDetails,date} =request.payload;        
//                   const result=await getTableData1.findOne({
//                     attributes: ['softwareId','price','quantity'],
//                     where:{softwareId:softwareIds},
//                   })
//                   if(request.query.purchase<=result.quantity)
//                   {
//                       //get table order and create order
//                     const createOrder=await getTableData.create({
//                       // orderId:orderId,
//                       softwareId:softwareIds,
//                       quantity:quantity,
//                       priceDetails:priceDetails,
//                       date:date,
//                       });
//                         const orderData=await getTableData.findOne
//                         ({
//                           attributes: ['orderId','softwareId','quantity','priceDetails'],
//                           where:{orderId:createOrder.orderId}
//                           });
//                           result.quantity=result.quantity-result1.quantity
//                           result1.priceDetails=result.price*result1.quantity
//                                   // console.log( 'aa',result1.priceDetails)
//                                   // console.log( 'aab',result.quantity)
//                                   //console.log('asss',orderIds)
//                                   // console.log( 'aac',result1.quantity)
//                                   // console.log('assas',result1)
//                                   //  const orderIds=result1.orderId
//                                   await result1.save()
//                                   await result.save()
//                                   const result3=await getTableData.findOne({
//                                     include: [
//                                     {
//                                       model: getTableData1,
//                                       required:true,
//                                       attributes: ['Name','description','price','imagePath']
//                                     }],
//                                     attributes: ['orderId','quantity','priceDetails'],
//                                     where:{orderId:createOrder.orderId}
//                                   })
//                                   return JSON.stringify(result3,null,2)
//         }
//         else{
//           return 'noooo order'
//         }
//     }
//       catch(err){
//         console.log('no machine id',err,)
//         }          
//          },
//           options: 
//           {
//             validate:
//              {
//                 params:Joi.object({
//                 softwareId:Joi.number(),
//               //   orderId:Joi.number().min(1)
//                   }),
//                         query:Joi.object({
//                     purchase:Joi.number().min(1)
//                     }),
//                         payload: Joi.object({
//                           quantity:Joi.number().min(1),
//                           priceDetails:Joi.number(),
//                           date:Joi.date()
//                         }),
//             },
//                 description: "Add softwareOrders",
//                 notes: "Returns a todo item by the id passed in the path",
//                 tags: ["api"], // ADD THIS TAG
//     },
//   };
// }
//   public addSoftwareOrders(){
//     return{
//       method: "POST",
//       path: "/addSoftwareOrders",
//       handler: async function (request: any, h: Hapi.ResponseToolkit) {
//          const dataBase = request.getDb("InventoryManagementDatabase");
//          console.log(dataBase)
//          const getTableData = dataBase.models.softwareOrders;
//          const getTableData1 = dataBase.models.softwares;
//          const softwareIds=request.payload.softwareId
//          console.log("database", getTableData1);
//          const {softwareId,quantity,priceDetails,date} =request.payload;
//          const result=await getTableData1.findOne({
//           attributes: ['quantity','price','softwareId'],
//           where:{softwareId:softwareIds},
//          // group:['machineId']
//         })
//         console.log("database", result.quantity);
//          if( result.quantity>=1){
//            await getTableData.create({
//           // orderId:orderId,
//           softwareId:softwareId,
//           quantity:quantity,
//           priceDetails:priceDetails,
//           date:date,
//          });
//          return JSON.stringify(result, null, 2);
//         }
//         else{
//           return 'no software available'
//         }
//      },
//      options: {
//        validate: {
//          query:Joi.object({
//           //softwareId:Joi.number()
//          }),
//          payload: Joi.object({
//           //orderId: Joi.number().min(1),
//            softwareId:Joi.number(),
//            quantity:Joi.number().min(1),
//            date:Joi.date()
//          }),
//        },
//        description: "Add softwareOrders",
//        notes: "Returns a todo item by the id passed in the path",
//        tags: ["api"], // ADD THIS TAG
//      },
//    };
//  }
//
// public updateSoftwareQuantity(){
//   return{
//     method:"PUT",
//     path:"/softwares/updateSoftwareQuantity/{softwareId}/{orderId}",
//     handler:async(request:any,h:Hapi.ResponseToolkit)=>
//     {
//       try{
//           const dataBase=await request.getDb('InventoryManagementDatabase')
//           const getTableData=dataBase.models.softwares
//           const getTableData1=dataBase.models.softwareOrders
//           const softwareId=request.params.softwareId
//           const orderId=request.params.orderId
//           const result=await getTableData.findOne({
//             attributes: ['quantity','softwareId'],
//             where:{softwareId:softwareId},
//            // group:['machineId']
//           })
//           console.log('ssassa',result)
//           if(result!==null)
//           {
//             const result1=await getTableData1.findOne({
//               attributes: ['quantity','softwareId','orderId'],
//               where:{orderId:orderId},
//               //group:['machineId']
//             });
//             console.log('assas',result1)
//             if(result1)
//             {
//               result.quantity=result.quantity -result1.quantity
//               console.log( 'aa',result.quantity)
//               if(result.quantity>=0){
//                 await result.save()
//                 return JSON.stringify(result,null,2)
//               }
//               else{
//                 return '0  product available'
//               }
//             }
//             else{
//               return  "orderId not match"
//             }
//           }
//           else{
//             return 'not software id available'
//           }
//         }
//         catch(err){
//           console.log(err)
//         }
//         },
//           options:{
//               validate:{
//                   params:Joi.object({
//                     softwareId:Joi.number(),
//                     orderId:Joi.number()
//                   }),
//                   // payload:Joi.object({
//                   //   quantity:Joi.number()
//                   // })
//                 },
//           description: " update quantity software ",
//           notes: "Returns a todo item by the id passed in the path",
//           tags: ["api"], // ADD THIS TAG
//     }
//   }
// }
// public updateSoftwarePrice(){
//   return{
//     method:"PUT",
//     path:"/softwares/updateSoftwarePrice/{softwareId}/{orderId}",
//     handler:async(request:any,h:Hapi.ResponseToolkit)=>
//     {
//       try{
//           const dataBase=await request.getDb('InventoryManagementDatabase')
//           const getTableData=dataBase.models.softwares
//           const getTableData1=dataBase.models.softwareOrders
//           const softwareId=request.params.softwareId
//           const orderId=request.params.orderId
//           const result=await getTableData.findOne({
//             attributes: ['price','softwareId'],
//             where:{softwareId:softwareId},
//            // group:['machineId']
//           })
//           console.log('ssassa',result)
//           if(result)
//           {
//             const result1=await getTableData1.findOne({
//               attributes: ['orderId','softwareId','quantity','priceDetails'],
//               where:{orderId:orderId},
//               //group:['machineId']
//             });
//             console.log('assas',result1)
//             if(result1)
//             {
//               result1.priceDetails=result.price*result1.quantity
//               console.log( 'aa',result1.priceDetails)
//                 await result1.save()
//                 return JSON.stringify(result1,null,2)
//               }
//               else{
//                 return 'orderId not available'
//               }
//             }
//           else{
//             return ' software id not fount'
//           }
//         }
//         catch(err){
//           console.log(err)
//         }
//         },
//           options:{
//               validate:{
//                   params:Joi.object({
//                     softwareId:Joi.number(),
//                     orderId:Joi.number()
//                   }),
//                   // payload:Joi.object({
//                   //   quantity:Joi.number()
//                   // })
//                 },
//           description: "price softwareOrders ",
//           notes: "Returns a todo item by the id passed in the path",
//           tags: ["api"], // ADD THIS TAG
//     }
//   }
// }
