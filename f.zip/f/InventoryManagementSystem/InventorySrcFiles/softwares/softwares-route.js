"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var softwareController_1 = require("./softwareController");
function default_1(server) {
    var software = new softwareController_1.softwareController();
    server.route(software.addNewSoftware());
    server.route(software.getAllSoftwareDetails());
    server.route(software.updateSoftwareDetails());
    server.route(software.deleteSoftwareDetails());
    server.route(software.countAllSoftwares());
    server.route(software.checkQuantityOfSoftware());
    server.route(software.filterSoftwarePrice());
    server.route(software.searchSoftwares());
}
exports.default = default_1;
