"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var machinesController_1 = require("./machinesController");
function default_1(server) {
    //machine routes
    var machines = new machinesController_1.machinesController();
    server.route(machines.addMachines());
    server.route(machines.getMachineDetails());
    server.route(machines.updateMachineDetails());
    server.route(machines.removeMachineDetails());
    server.route(machines.countMachine());
    server.route(machines.quantityOfMachines());
    server.route(machines.filterPrice());
    server.route(machines.searchMachine());
}
exports.default = default_1;
